package org.jfree.data.test;


import static org.junit.Assert.*;
import org.jfree.data.Range;
import org.junit.*;

public class RangeTest {

	//The following Range objects will be used for testing methods : constrain, contain, and getLength 
	private Range Range1; //Will be (LB, AB)
	private Range Range2; //Will be (AB, AB)
	private Range Range3; //Will be (LB,LB)
	private Range Range4; 
	
	//The following data will be used for the weak robust testing on getUpperBounds and getLowerBounds as outlined in the lab document. 
	//the following Range objects will be used for testing methods: getUpperBounds and getLowerBounds on both extremes of (minPossibleDouble, maxPossibleDouble)
	private Range extremeR1; //Will be (BLB, NOM)
	private Range extremeR2; //Will be (LB, NOM)
	private Range extremeR3; //Will be (NOM, NOM)
	private Range extremeR4; //Will be (NOM, AB)
	private Range extremeR5; //Will be (NOM, AUB)
	private Range extremeR6; //Will be (LB, UB)
	private Range extremeR7; //Will be (BLB, AUB)
	
	static private double maxPossibleDouble = 9223372036854775807.0;//the maximum possible double - for testing when upper bounds method is ABOVE or at the maximum allowable double. 
	static private double minPossibleDouble = -9223372036854775808.0;//the minimum possible double - for testing when lower bounds method is BELOW or at the minimum allowable double. 
	
	
	//setup operations for the test SUIT: 
	
	@BeforeClass public static void setUpBeforeClass()
	throws Exception{}
	
	
	@Before
	public void setUp() throws Exception{

		//initializing the constrain, contain and getLength method range testing objects
		//For Reference AB = 5, LB = -5, NOM = LB <= x <= AB, AUB = x > AB, BLB = x < LB 
		Range1 = new Range(-5,5);
		Range2 = new Range (5,5);
		Range3 = new Range(-5,-5);
		
		//initialize the extreme range tests. For simplicity sake, let NOM = 100.0 
		extremeR1 = new Range(-9223372036854775808.0 -1, 100.0);
		extremeR2 = new Range(-9223372036854775808.0, 100.0);
		extremeR3 = new Range(100.0, 100.0);
		extremeR4 = new Range(100.0, 9223372036854775807.0);
		extremeR5 = new Range(100.0, 9223372036854775807.0 + 1);
		extremeR6 = new Range(-9223372036854775808.0, 9223372036854775807.0);
		extremeR7 = new Range(-9223372036854775808.0 -1, 9223372036854775807.0 + 1);

		
	}
	@Test
	public void centralValueShouldBeZero() {
		assertEquals("The central value of -5 and 5 should be 0",
				0, Range1.getCentralValue(), .000000001d);
	}
	
	//end of setup operations 
	
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	//Testing for constrain method of Range class, following the weak robust test strategy: 	
	@Test
	public void constrainShouldReturnUpperValueForRange1() { //tests AUB input on a range of (LB,AB)
		assertEquals("Constrain of 7 should be 5 for -5 and 5", 5, Range1.constrain(7),.000000001d);
	}
	
	@Test
	public void constrainShouldReturnLowerValueForRange1() { //tests BLB input on a range of (LB,AB)
		assertEquals("Constrain of -7 should be -5 for -5 and 5", -5, Range1.constrain(-7),.000000001d);
	}
	
	@Test
	public void constrainShouldReturnItselfForRange1() { //tests NOM input on a range of (LB,AB)
		assertEquals("Constrain of 3 should be 3 for -5 and 5", 3, Range1.constrain(3),.000000001d);
	}
	
	@Test
	public void constrainShouldReturnUpperValueForRange2() { //tests AUB input on a range of (AB,AB)
		assertEquals("Constrain of 7 should be 5 for 5 and 5", 5, Range2.constrain(7),.000000001d);
	}
	
	@Test
	public void constrainShouldReturnLowerValueForRange2() { //tests BLB input on a range of (AB,AB)
		assertEquals("Constrain of -7 should be 5 for 5 and 5", 5, Range2.constrain(-7),.000000001d);
	}
	
	@Test
	public void constrainShouldReturnItselfForRange2() { //tests NOM input on a range of (AB,AB)
		assertEquals("Constrain of 5 should be 5 for 5 and 5", 5, Range2.constrain(5),.000000001d);
	}
	
	@Test
	public void constrainShouldReturnUpperValueForRange3() { //tests AUB input on a range of (LB,LB)
		assertEquals("Constrain of 7 should be -5 for -5 and -5", -5, Range3.constrain(7),.000000001d);
	}
	
	@Test
	public void constrainShouldReturnLowerValueForRange3() { //tests BLB input on a range of (AB,AB)
		assertEquals("Constrain of -7 should be -5 for -5 and -5", -5, Range3.constrain(-7),.000000001d);
	}
	
	@Test
	public void constrainShouldReturnItselfForRange3() { //tests NOM input on a range of (AB,AB)
		assertEquals("Constrain of -5 should be -5 for -5 and -5", -5, Range3.constrain(-5),.000000001d);
	}
	
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	//Testing for contains method in Range class, following the weak robust testing strategy:
	@Test
	public void containShouldReturnTrueForRange1() {//test NOM input on a range of (LB,AB)
		assertTrue("Contain of 3 should be true for -5 and 5", Range1.contains(3));
	}
	
	@Test
	public void containInputAUBShouldReturnFalseForRange1() {//test AUB input on a range of (LB,AB)
		assertFalse("Contain of 7 should be false for -5 and 5", Range1.contains(7));
	}
	
	@Test
	public void containInputBLBShouldReturnFalseForRange1() {//test BLB input on a range of (LB,AB)
		assertFalse("Contain of -7 should be false for -5 and 5", Range1.contains(-7));
	}
	
	@Test
	public void containShouldReturnTrueForRange2() {//test NOM input on a range of (AB,AB)
		assertTrue("Contain of 5 should be true for 5 and 5", Range2.contains(5));
	}
	
	@Test
	public void containInputAUBShouldReturnFalseForRange2() {//test AUB input on a range of (AB,AB)
		assertFalse("Contain of 7 should be false for 5 and 5", Range2.contains(7));
	}
	
	@Test
	public void containInputBLBShouldReturnFalseForRange2() {//test BLB input on a range of (AB,AB)
		assertFalse("Contain of -7 should be false for 5 and 5", Range2.contains(-7));
	}
	
	@Test
	public void containShouldReturnTrueForRange3() {//test NOM input on a range of (LB,LB)
		assertTrue("Contain of -5 should be true for -5 and -5", Range3.contains(-5));
	}
	
	@Test
	public void containInputAUBShouldReturnFalseForRange3() {//test AUB input on a range of (LB,LB)
		assertFalse("Contain of 7 should be false for -5 and -5", Range3.contains(7));
	}
	
	@Test
	public void containInputBLBShouldReturnFalseForRange3() {//test BLB input on a range of (LB,LB)
		assertFalse("Contain of -7 should be false for -5 and -5", Range3.contains(-7));
	}
	
	
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	//Testing for getLowerBounds method of Range class, following the weak robust testing strategy:
	//Note: The arbitrarily chosen nominal value was set to 100.0, as it is a simple number, and remains within the range of {minPossibleDouble, maxPossibleDouble}
	
	@Test 
	public void lowerBoundTest1() { //Tests (BLB, NOM) 
		assertEquals("getLowerBound of (-9223372036854775809.0, 100.0) should be -9223372036854775809.0", -9223372036854775809.0, extremeR1.getLowerBound(),.000000001d);
	}
	
	@Test 
	public void lowerBoundTest2() { //Tests (LB, NOM)
		assertEquals("getLowerBound of (-9223372036854775808.0, 100.0) should be -9223372036854775808.0", -9223372036854775808.0, extremeR2.getLowerBound(),.000000001d);
	}
	
	@Test 
	public void lowerBoundTest3() { //Tests (NOM, NOM)
		assertEquals("getLowerBound of (100.0, 100.0) should be 100.0", 100.0, extremeR3.getLowerBound(),.000000001d);
	}
	
	@Test 
	public void lowerBoundTest4() { //tests (NOM, AB)
		assertEquals("getLowerBound of (100.0, 9223372036854775807.0) should be 100.0", 100.0, extremeR4.getLowerBound(),.000000001d);
	}
	
	@Test 
	public void lowerBoundTest5() { //tests (NOM, AUB)
		assertEquals("getLowerBound of (100.0, 9223372036854775808.0) should be 100.0", 100.0, extremeR5.getLowerBound(),.000000001d);
	}
	
	@Test 
	public void lowerBoundTest6() { //tests (LB, UB)
		assertEquals("getLowerBound of (-9223372036854775808.0, 9223372036854775807.0) should be -9223372036854775808.0", -9223372036854775808.0, extremeR6.getLowerBound(),.000000001d);
	}
	
	@Test 
	public void lowerBoundTest7() { //tests (BLB, AUB)
		assertEquals("getLowerBound of (-9223372036854775809.0, 9223372036854775808.0) should be -9223372036854775809.0", -9223372036854775809.0, extremeR7.getLowerBound(),.000000001d);
	}
	
	
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	//Testing for getUpperBound method of Range class, following the weak robust testing strategy: 
	//Note: The arbitrarily chosen nominal value was set to 100.0, as it is a simple number, and remains within the range of {minPossibleDouble, maxPossibleDouble}
	
	@Test 
	public void upperBoundTest1() { //Tests (BLB, NOM) 
		assertEquals("getUpperBound of (-9223372036854775809.0, 100.0) should be 100.0", 100.0, extremeR1.getUpperBound(),.000000001d);
	}
	
	@Test 
	public void upperBoundTest2() { //Tests (LB, NOM)
		assertEquals("getUpperBound of (-9223372036854775808.0, 100.0) should be 100.0", 100.0, extremeR2.getUpperBound(),.000000001d);
	}
	
	@Test 
	public void upperBoundTest3() { //Tests (NOM, NOM)
		assertEquals("getUpperBound of (100.0, 100.0) should be 100.0", 100.0, extremeR3.getUpperBound(),.000000001d);	
	}
	
	@Test 
	public void upperBoundTest4() { //tests (NOM, AB)
		assertEquals("getUpperBound of (100.0, 9223372036854775807.0) should be 9223372036854775807.0", 9223372036854775807.0, extremeR4.getUpperBound(),.000000001d);	
	}
	
	@Test 
	public void upperBoundTest5() { //tests (NOM, AUB)
		assertEquals("getUpperBound of (100.0, 9223372036854775808.0) should be 9223372036854775808.0", 9223372036854775808.0, extremeR5.getUpperBound(),.000000001d);
	}
	
	@Test 
	public void upperBoundTest6() { //tests (LB, UB)
		assertEquals("getUpperBound of (-9223372036854775808.0, 9223372036854775807.0) should be 9223372036854775807.0", 9223372036854775807.0, extremeR6.getUpperBound(),.000000001d);
	}
	
	@Test 
	public void upperBoundTest7() { //tests (BLB, AUB)
		assertEquals("getUpperBound of (-9223372036854775809.0, 9223372036854775808.0) should be 9223372036854775808.0", 9223372036854775808.0, extremeR7.getUpperBound(),.000000001d);
		
	}
	
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////	
    //Testing for getLengh, following the weak robust testing strategy: 
    
    @Test
    public void getLengthR1() {
        
        //expected to get a length of 10, ranging from negative to a positive boundary
        assertEquals("getLength for range (-5,5) should be 10", 10, Range1.getLength(),.000000001d);
        
    }
    
    @Test
    public void getLengthR2() {
        //expected to get a length of 0 ranging from lower bounds and upper bounds being identical 
        assertEquals("getLength for range (5,5) should be 0", 0, Range2.getLength(),.000000001d);
    }
    
    @Test
    public void getLengthR3() {
        //again, expected to get a length of 0 ranging from lower bounds and upper bounds being identical But this time both are negative values 
        assertEquals("getLength for range (-5,-5) should be 0", 0, Range3.getLength(),.000000001d);
    }
    
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////after all test cases have been executed: perform teardown. 
	
	@After
	public void tearDown() throws Exception{
	}
	@AfterClass
	public static void tearDownAfterClass() throws Exception{
		
	}
	
	
	

}
