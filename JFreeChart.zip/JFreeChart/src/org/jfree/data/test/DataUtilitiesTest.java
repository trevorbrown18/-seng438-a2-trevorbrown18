package org.jfree.data.test;

import static org.junit.Assert.*;

import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.List;

import org.jfree.data.DataUtilities;
import org.jfree.data.KeyedValue;
import org.jfree.data.KeyedValues;
import org.jfree.data.Values;
import org.jfree.data.Values2D;
import org.jmock.Expectations;
import org.jmock.Mockery;
import org.junit.*;

public class DataUtilitiesTest {
	
	//@BeforeClass
	public void setUpBeforeClass() throws Exception{
		
	}
	
	//@Before
	public void setUp() throws Exception{
	
	}
	
	//=============================================================================
		//* The following tests are conducted under a weak robust testing strategy, 
		//* with the following test cases being run for both
		//* createNumberArray and createNumberArray2D:
		//* 
		//* (AUB, NOM), (ALB, NOM), (UB, NOM), (LB, NOM), (BLB, NOM), (BUB, NOM), 
		//* (NOM, NOM),(NOM, AUB), (NOM, ALB), (NOM, UB), (NOM, LB), (NOM, BLB), 
		//* (NOM, BUB),
		//* 
		//* Where: 
		//* NOM: nominal value
		//* AUB: above upper bound
		//* UB: upper bound
		//* BUB: below upper bound
		//* BLB: below lower bound
		//* LB: lower bound
		//* ALB: above lower bound.
		//* 
		//* The first variable in each test case is the size of each individual value in the array,
		//* and the second variable is the size of the array
	//=============================================================================

		@Test
		/**
		 * Nominal Test for createNumberArray
		 */
		public void NomNom()
		{		
			double [] data1 = {1, 2, 3, 4, 5, 5.5, 6.7, 8}; // prepare array
			java.lang.Number [] res1 = DataUtilities.createNumberArray(data1);
			for(int i = 0; i < data1.length; i++)
			{
				// checks for null or incorrect values
				assertTrue("This value should not be null if copied properly", res1[i] != null); 
				assertTrue(data1[i] == res1[i].doubleValue()); 
			}
		}
		
		@Test 
		/*
		 * Nominal Test for createNumberArray2D
		 */
		public void NomNom2D()
		{
			double [][] data2 = {{1, 4, 4.5, 6.7}, {2.3, 4.3, 49.5, 190}, {290.28, 192, 183.28, 110.22}}; // prepare array
			Number [][] res2 = DataUtilities.createNumberArray2D(data2); // call function
			for(int i = 0; i < data2.length; i++)
			{
				for(int j = 0; j < data2[i].length; j++)
				{
					// checks for null or incorrect values
					assertTrue("This value should not be null if copied properly", res2[i][j] != null);
					assertTrue(data2[i][j] == res2[i][j].doubleValue());
				}
			}
		}
		
		@Test
		/**
		 * Nominal data values tested at above the lower bound of array size for createNumberArray
		 */
		public void NomAlb()
		{
			double [] data1 = {1, 2}; // prepare array
			java.lang.Number [] res1 = DataUtilities.createNumberArray(data1); // call function
			for(int i = 0; i < data1.length; i++)
			{
				// checks for null or incorrect values
				assertTrue("This value should not be null if copied properly", res1[i] != null);
				assertTrue(data1[i] == res1[i].doubleValue());
			}
		}
		
		@Test
		/**
		 * Nominal data values tested at above the lower bound of array size for createNumberArray2D
		 */
		public void NomAlb2D()
		{
			double [][] data2 = {{2, 3.4}, {1, 5.5}}; // prepare array
			java.lang.Number [][] res2 = DataUtilities.createNumberArray2D(data2); // call function
			for(int i = 0; i < data2.length; i++)
			{
				for(int j = 0; j < data2[i].length; j++)
				{
					// checks for null or incorrect values
					assertTrue("This value should not be null if copied properly", res2[i][j] != null);
					assertTrue(data2[i][j] == res2[i][j].doubleValue());
				}
			}
		}
		
		@Test
		/**
		 * Nominal data values tested at the lower bound of array size for createNumberArray
		 */
		public void NomLb()
		{
			double [] data1 = {1}; // prepare array
			java.lang.Number [] res1 = DataUtilities.createNumberArray(data1); // call function
			for(int i = 0; i < data1.length; i++)
			{
				// check for null or incorrect values
				assertTrue("This value should not be null if copied properly", res1[i] != null);
				assertTrue(data1[i] == res1[i].doubleValue());
			}
		}
		
		@Test
		/**
		 * Nominal data values tested at the lower bound of array size for createNumberArray2D
		 */
		public void NomLb2D()
		{
			double [][] data2 = {{-2.3}, {1.9}}; // prepare array
			java.lang.Number [][] res2 = DataUtilities.createNumberArray2D(data2); // call function
			for(int i = 0; i < data2.length; i++)
			{
				for(int j = 0; j < data2[i].length; j++)
				{
					// check for null or incorrect values
					assertTrue("This value should not be null if copied properly", res2[i][j] != null);
					assertTrue(data2[i][j] == res2[i][j].doubleValue());
				}
			}
		}
		
		@Test
		/**
		 * Nominal data values tested below the lower bound of array size for createNumberArray
		 */
		public void NomBlb()
		{
			double [] data1 = null;
			try // call function in try/catch to allow retrieval of IllegalArgumentException
			{
				java.lang.Number [] res1 = DataUtilities.createNumberArray(data1);
			}
			catch(IllegalArgumentException e)
			{
				//conditional statement to formalize test result
				assertTrue(data1 == null); 
			}
		}
		
		@Test
		/**
		 * Nominal data values tested below the lower bound of array size for createNumberArray2D
		 */
		public void NomBlb2D()
		{
			double [][] data2 = null;
			try // call function in try/catch to allow retrieval of IllegalArgumentException
			{
				java.lang.Number [][] res2 = DataUtilities.createNumberArray2D(data2);
			}
			catch(IllegalArgumentException e)
			{
				//conditional statement to formalize test result
				assertTrue(data2  == null);
			}
		}
		
		@Test
		/**
		 * Nominal data values tested below the upper bound of array size for createNumberArray
		 * 
		 * NOTE: The upper bound of array sizing is assumed to be 100, which represents maximum practical array usage
		 */
		public void NomBub()
		{
			double [] data1 = new double [90];
			for(int i = 0; i < data1.length; i++) // prepare array
			{
				data1[i] = i+0.1228;
			}
			Number [] res1 = DataUtilities.createNumberArray(data1); // call function
			for(int i = 0; i < data1.length; i++)
			{
				//check for null or incorrect values
				assertTrue("This value should not be null if copied properly", res1[i] != null);
				assertTrue(data1[i] == res1[i].doubleValue());
			}
		}
		
		@Test
		/**
		 * Nominal data values tested below the upper bound of array size for createNumberArray2D
		 * 
		 * NOTE: The upper bound of array sizing is assumed to be 100, which represents maximum practical array usage
		 */
		public void NomBub2D()
		{
			double [][] data2 = new double [90][90];
			for(int i = 0; i < data2.length; i++) // prepare array
			{
				for(int j = 0; j < data2[i].length; j++)
				{
					data2[i][j] = j+0.2343;
				}
			}
			Number [][] res2 = DataUtilities.createNumberArray2D(data2); // call function
			for(int i = 0; i < data2.length; i++)
			{
				for(int j = 0; j < data2[i].length; j++)
				{
					// check for null or incorrect values 
					assertTrue("This value should not be null if copied properly", res2[i][j] != null);
					assertTrue(data2[i][j] == res2[i][j].doubleValue());
				}
			}
		}
		
		@Test
		/**
		 * Nominal data values tested at the upper bound of array size for createNumberArray
		 * 
		 * NOTE: The upper bound of array sizing is assumed to be 100, which represents maximum practical array usage
		 */
		public void NomUb()
		{
			double [] data1 = new double [100];
			for(int i = 0; i < data1.length; i++) // prepare array
			{
				data1[i] = i+0.1426;
			}		
			java.lang.Number [] res1 = DataUtilities.createNumberArray(data1); // call function
			for(int i = 0; i < data1.length; i++)
			{
				// check for null or incorrect values
				assertTrue("This value should not be null if copied properly", res1[i] != null);
				assertTrue(data1[i] == res1[i].doubleValue());
			}
		}
		
		
		@Test
		/**
		 * Nominal data values tested at the upper bound of array size for createNumberArray2D
		 * 
		 * NOTE: The upper bound of array sizing is assumed to be 100, which represents maximum practical array usage
		 */
		public void NomUb2D()
		{
			double [][] data2 = new double [100][100];
			for(int i = 0; i < data2.length; i++) // prepare array
			{
				for(int j = 0; j < data2[i].length; j++)
				{
					data2[i][j] = j+1325;
				}
			}
			java.lang.Number [][] res2 = DataUtilities.createNumberArray2D(data2); // call function
			for(int i = 0; i < data2.length; i++)
			{
				for(int j = 0; j < data2[i].length; j++)
				{
					//check for null or incorrect values
					assertTrue("This value should not be null if copied properly", res2[i][j] != null);
					assertTrue(data2[i][j] == res2[i][j].doubleValue());
				}
			}
		}
		
		@Test
		/**
		 * Nominal data values tested above the upper bound of array size for createNumberArray
		 * 
		 * NOTE: The upper bound of array sizing is assumed to be 100, which represents maximum practical array usage
		 */
		public void NomAub()
		{
			double [] data1 = new double [110];
			for(int i = 0; i < data1.length; i++) // prepare array
			{
				data1[i] = i+0.3564;
			}		
			java.lang.Number [] res1 = DataUtilities.createNumberArray(data1); //call function
			for(int i = 0; i < data1.length; i++)
			{
				//check for null or incorrect values
				assertTrue("This value should not be null if copied properly", res1[i] != null);
				assertTrue(data1[i] == res1[i].doubleValue());
			}
		}
		
		
		@Test
		/**
		 * Nominal data values tested above the upper bound of array size for createNumberArray
		 * 
		 * NOTE: The upper bound of array sizing is assumed to be 100, which represents maximum practical array usage
		 */
		public void NomAub2D()
		{
			double [][] data2 = new double [110][110];

			for(int i = 0; i < data2.length; i++) // prepare array
			{
				for(int j = 0; j < data2[i].length; j++)
				{
					data2[i][j] = j+0.3636;
				}
			}
			java.lang.Number [][] res2 = DataUtilities.createNumberArray2D(data2); // call function
			for(int i = 0; i < data2.length; i++)
			{
				for(int j = 0; j < data2[i].length; j++)
				{
					// check for null or incorrect values
					assertTrue("This value should not be null if copied properly", res2[i][j] != null);
					assertTrue(data2[i][j] == res2[i][j].doubleValue());
				}
			}
		}
		
		
		@Test
		/**
		 * Data values at the lower bound tested at a nominal array size for createNumberArray
		 */
		public void LbNom()
		{
			double [] data1 = new double [5];		
			for(int i = 0; i < data1.length; i++) // prepare array
			{
				data1[i] = Double.MIN_VALUE;
			}
			
			java.lang.Number [] res1 = DataUtilities.createNumberArray(data1); // call function
			for(int i = 0; i < data1.length; i++)
			{
				//check for null or incorrect values
				assertTrue("This value should not be null if copied properly", res1[i] != null);
				assertTrue(data1[i] == res1[i].doubleValue());
			}
			
		}
		
		
		@Test
		/**
		 * Data values at the lower bound tested at a nominal array size for createNumberArray2D
		 */
		public void LbNom2D()
		{
			double [][] data2 = new double [5][5];
			for(int i = 0; i < data2.length; i++) // prepare array
			{
				for(int j = 0; j < data2[i].length; j++)
				{
					data2[i][j] = Double.MIN_VALUE;
				}
			}
			java.lang.Number [][] res2 = DataUtilities.createNumberArray2D(data2); // call function
			for(int i = 0; i < data2.length; i++)
			{
				for(int j = 0; j < data2[i].length; j++)
				{
					// check for null or incorrect
					assertTrue("This value should not be null if copied properly", res2[i][j] != null);
					assertTrue(data2[i][j] == res2[i][j].doubleValue());
				}
			}
			
		}
		
		@Test
		/**
		 * Data values below the lower bound tested at a nominal array size for createNumberArray
		 */
		public void BlbNom()
		{
			double [] data1 = new double [5];		
			for(int i = 0; i < data1.length; i++) // prepare array
			{
				data1[i] = Double.MIN_VALUE - 200;
			}	
			java.lang.Number [] res1 = DataUtilities.createNumberArray(data1); // call function
			for(int i = 0; i < data1.length; i++)
			{
				// check for null or incorrect values
				assertTrue("This value should not be null if copied properly", res1[i] != null);
				assertTrue(data1[i] == res1[i].doubleValue());
			}
		}
		
		@Test
		/**
		 * Data values below the lower bound tested at a nominal array size for createNumberArray2D
		 */
		public void BlbNom2D()
		{
			double [][] data2 = new double [5][5];
			for(int i = 0; i < data2.length; i++) // prepare array
			{
				for(int j = 0; j < data2[i].length; j++)
				{
					data2[i][j] = Double.MIN_VALUE - 200;
				}
			}
			java.lang.Number [][] res2 = DataUtilities.createNumberArray2D(data2); // call function
			for(int i = 0; i < data2.length; i++)
			{
				for(int j = 0; j < data2[i].length; j++)
				{
					// check for null or incorrect values
					assertTrue("This value should not be null if copied properly", res2[i][j] != null);
					assertTrue(data2[i][j] == res2[i][j].doubleValue());
				}
			}
			
		}
		
		@Test
		/**
		 * Data values below the upper bound tested at a nominal array size for createNumberArray
		 */
		public void BubNom()
		{
			double [] data1 = new double [5];		
			for(int i = 0; i < data1.length; i++) // prepare array
			{
				data1[i] = Double.MAX_VALUE - 1000*(i+1);
			}
			
			java.lang.Number [] res1 = DataUtilities.createNumberArray(data1); // call function
			for(int i = 0; i < data1.length; i++)
			{
				// check for null or incorrect values
				assertTrue("This value should not be null if copied properly", res1[i] != null);
				assertTrue(data1[i] == res1[i].doubleValue());
			}
			
		}
		
		@Test
		/**
		 * Data values below the upper bound tested at a nominal array size for createNumberArray2D
		 */
		public void BubNom2D()
		{
			double [][] data2 = new double [5][5];

			for(int i = 0; i < data2.length; i++) // prepare array
			{
				for(int j = 0; j < data2[i].length; j++)
				{
					data2[i][j] = Double.MAX_VALUE - 1000*(i+1);
				}
			}
			
			java.lang.Number [][] res2 = DataUtilities.createNumberArray2D(data2); //call function
			for(int i = 0; i < data2.length; i++)
			{
				for(int j = 0; j < data2[i].length; j++)
				{
					// check for null or incorrect values
					assertTrue("This value should not be null if copied properly", res2[i][j] != null);
					assertTrue(data2[i][j] == res2[i][j].doubleValue());
				}
			}
			
		}
		
		@Test
		/**
		 * Data values above the lower bound tested at a nominal array size for createNumberArray
		 */
		public void AlbNom()
		{
			double [] data1 = new double [5];		
			for(int i = 0; i < data1.length; i++) // prepare array
			{
				data1[i] = Double.MIN_VALUE + 1000*(i+1);
			}
			java.lang.Number [] res1 = DataUtilities.createNumberArray(data1); // call function

			for(int i = 0; i < data1.length; i++)
			{
				// check for null or incorrect values
				assertTrue("This value should not be null if copied properly", res1[i] != null);
				assertTrue(data1[i] == res1[i].doubleValue());
			}

			
		}
		
		
		@Test
		/**
		 * Data values above the lower bound tested at a nominal array size for createNumberArray2D
		 */
		public void AlbNom2D()
		{
			double [][] data2 = new double [5][5];
			
			for(int i = 0; i < data2.length; i++) // prepare array
			{
				for(int j = 0; j < data2[i].length; j++)
				{
					data2[i][j] = Double.MIN_VALUE + 1000*(i+1);
				}
			}
			
			java.lang.Number [][] res2 = DataUtilities.createNumberArray2D(data2); //call function

			for(int i = 0; i < data2.length; i++)
			{
				for(int j = 0; j < data2[i].length; j++)
				{
					// check for null or incorrect values
					assertTrue("This value should not be null if copied properly", res2[i][j] != null);
					assertTrue(data2[i][j] == res2[i][j].doubleValue());
				}
			}
			
		}
		
		@Test
		/**
		 * Data values above the upper bound tested at a nominal array size for createNumberArray
		 */
		public void AubNom()
		{
			double [] data1 = new double [5];
			
			for(int i = 0; i < data1.length; i++) // prepare array
			{
				data1[i] = Double.MAX_VALUE + 200;
			}

			
			java.lang.Number [] res1 = DataUtilities.createNumberArray(data1); // call function
			for(int i = 0; i < data1.length; i++)
			{
				//check for null or incorrect values
				assertTrue("This value should not be null if copied properly", res1[i] != null);
				assertTrue(data1[i] == res1[i].doubleValue());
			}
			
		}
		
		@Test
		/**
		 * Data values above the upper bound tested at a nominal array size for createNumberArray2D
		 */
		public void AubNom2D()
		{
			double [][] data2 = new double [5][5];
			
			for(int i = 0; i < data2.length; i++)
			{
				for(int j = 0; j < data2[i].length; j++) // prepare array
				{
					data2[i][j] = Double.MAX_VALUE + 200;
				}
			}
			
			java.lang.Number [][] res2 = DataUtilities.createNumberArray2D(data2); // call function
			for(int i = 0; i < data2.length; i++)
			{
				for(int j = 0; j < data2[i].length; j++)
				{
					//check for null or incorrect values
					assertTrue("This value should not be null if copied properly", res2[i][j] != null);
					assertTrue(data2[i][j] == res2[i][j].doubleValue());
				}
			}
			
		}

		@Test
		/**
		 * Data values at the upper bound tested at a nominal array size for createNumberArray
		 */
		public void UbNom()
		{
			double [] data1 = new double [5];
			
			for(int i = 0; i < data1.length; i++) // prepare array
			{
				data1[i] = Double.MAX_VALUE;
			}

			java.lang.Number [] res1 = DataUtilities.createNumberArray(data1); // call function

			for(int i = 0; i < data1.length; i++)
			{
				//check for null or incorrect values
				assertTrue("This value should not be null if copied properly", res1[i] != null);
				assertTrue(data1[i] == res1[i].doubleValue());
			}

			
		}
		
		@Test
		/**
		 * Data values at the upper bound tested at a nominal array size for createNumberArray2D
		 */
		public void UbNom2D()
		{
			double [][] data2 = new double [5][5];
			
			for(int i = 0; i < data2.length; i++) // prepare array
			{
				for(int j = 0; j < data2[i].length; j++)
				{
					data2[i][j] = Double.MAX_VALUE;
				}
			}
			
			java.lang.Number [][] res2 = DataUtilities.createNumberArray2D(data2); // call function
			for(int i = 0; i < data2.length; i++)
			{
				for(int j = 0; j < data2[i].length; j++)
				{
					//check for null or incorrect values
					assertTrue("This value should not be null if copied properly", res2[i][j] != null);
					assertTrue(data2[i][j] == res2[i][j].doubleValue());
				}
			}
			
		}
	
	//=============================================================
		//CalculateRowTotal
	//=============================================================================
		// The test strategy used for CalculateRowTotal was Weak Robust Testing methods
		// The three main variables that were being tested were the selected row(Row),
		// the size of the Values2D array(Array), and the size of the value stored
		// in each cell(Value)
		// The Modifier After the variables states how that variable was tested, AUB(Above Upper
		// Bound), UB(Upper Bound), BUB(Below Upper Bound), NOM(Nominal), ALB(Above Upper Bound),
		// LB(Lower Bound), and BLB(Below Lower Bound)
		// The Upper and Lower Bounds are specified in the document
	//=============================================================================
	
	@Test
	/**
	 * Nominal Test for calculateRowTotal
	 */
	public void calculateRowTotal_NOM(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(50));
				one(nomValues).getColumnCount();
				will(returnValue(50));
				for(int i = 0; i < 50; i++) {
					one(nomValues).getValue(25,i);
					will(returnValue(1000));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateRowTotal(nomValues,25);
		//verify
		assertEquals(result, 1000*50, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Above Upper Bound for Row Selected for calculateRowTotal
	 */
	public void calculateRowTotal_RowAUB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(50));
				one(nomValues).getColumnCount();
				will(returnValue(50));
				for(int i = 0; i < 50; i++) {
					one(nomValues).getValue(60,i);
					will(returnValue(1000));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateRowTotal(nomValues,60);
		//verify
		assertEquals(result, 0, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Upper Bound for Row Selected for calculateRowTotal
	 */
	public void calculateRowTotal_RowUB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(50));
				one(nomValues).getColumnCount();
				will(returnValue(50));
				for(int i = 0; i < 50; i++) {
					one(nomValues).getValue(49,i);
					will(returnValue(1000));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateRowTotal(nomValues,49);
		//verify
		assertEquals(result, 1000*50, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Below Upper Bound for row Selected for calculateRowTotal
	 */
	public void calculateRowTotal_RowBUB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(50));
				one(nomValues).getColumnCount();
				will(returnValue(50));
				for(int i = 0; i < 50; i++) {
					one(nomValues).getValue(45,i);
					will(returnValue(1000));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateRowTotal(nomValues,45);
		//verify
		assertEquals(result, 1000*50, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Above Lower Bound for Row Selected for calculateRowTotal
	 */
	public void calculateRowTotal_RowALB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(50));
				one(nomValues).getColumnCount();
				will(returnValue(50));
				for(int i = 0; i < 50; i++) {
					one(nomValues).getValue(5,i);
					will(returnValue(1000));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateRowTotal(nomValues,5);
		//verify
		System.out.println(result);
		assertEquals(result, 1000*50, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Lower Bound for Row Selected for calculateRowTotal
	 */
	public void calculateRowTotal_RowLB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(50));
				one(nomValues).getColumnCount();
				will(returnValue(50));
				for(int i = 0; i < 50; i++) {
					one(nomValues).getValue(0,i);
					will(returnValue(1000));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateRowTotal(nomValues,0);
		//verify
		assertEquals(result, 1000*50, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Below Lower Bound for Row Selected for calculateRowTotal
	 */
	public void calculateRowTotal_RowBLB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(50));
				one(nomValues).getColumnCount();
				will(returnValue(50));
				for(int i = 0; i < 50; i++) {
					one(nomValues).getValue(-1,i);
					will(returnValue(1000));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateRowTotal(nomValues,-1);
		//verify
		assertEquals(result, 0, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Above Upper Bound for Array Size for calculateRowTotal
	 */
	public void calculateRowTotal_ArrayAUB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(200));
				one(nomValues).getColumnCount();
				will(returnValue(200));
				for(int i = 0; i < 200; i++) {
					one(nomValues).getValue(100,i);
					will(returnValue(1000));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateRowTotal(nomValues,100);
		//verify
		assertEquals(result, 1000*200, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Upper Bound for Array Size for calculateRowTotal
	 */
	public void calculateRowTotal_ArrayUB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(100));
				one(nomValues).getColumnCount();
				will(returnValue(100));
				for(int i = 0; i < 100; i++) {
					one(nomValues).getValue(50,i);
					will(returnValue(1000));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateRowTotal(nomValues,50);
		//verify
		assertEquals(result, 1000*100, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	
	@Test
	/**
	 * Below Upper Bound for Array Size for calculateRowTotal
	 */
	public void calculateRowTotal_ArrayBUB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(95));
				one(nomValues).getColumnCount();
				will(returnValue(90));
				for(int i = 0; i < 90; i++) {
					one(nomValues).getValue(45,i);
					will(returnValue(1000));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateRowTotal(nomValues,45);
		//verify
		assertEquals(result, 1000*90, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Above Lower Bound for Array Size for calculateRowTotal
	 */
	public void calculateRowTotal_ArrayALB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(3));
				one(nomValues).getColumnCount();
				will(returnValue(5));
				for(int i = 0; i < 5; i++) {
					one(nomValues).getValue(2,i);
					will(returnValue(1000));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateRowTotal(nomValues,2);
		//verify
		assertEquals(result, 1000*5, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Lower Bound for Array Size for calculateRowTotal
	 */
	public void calculateRowTotal_ArrayLB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(0));
				one(nomValues).getColumnCount();
				will(returnValue(0));
				for(int i = 0; i < 0; i++) {
					one(nomValues).getValue(0,i);
					will(returnValue(1000));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateRowTotal(nomValues,0);
		//verify
		assertEquals(result, 1000*0, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Below Lower Bound for Array Size for calculateRowTotal
	 */
	public void calculateRowTotal_ArrayBLB(){
		//setup
		try {
			Mockery mockingContext = new Mockery();
			Values2D nomValues = mockingContext.mock(Values2D.class);
			mockingContext.checking(new Expectations() {
				{
					one(nomValues).getRowCount();
					will(returnValue(-1));
					one(nomValues).getColumnCount();
					will(returnValue(-1));
					for(int i = -1; i < 1; i++) {
						one(nomValues).getValue(-1,i);
						will(returnValue(1000));
					}
				}
			}); 
			
			//exercise
			double result = DataUtilities.calculateRowTotal(null,-1);
			//verify
			assertEquals(result, 0, .000000001d);
			
		}catch(InvalidParameterException e) {
			assertEquals(1,1);
		}catch(Exception e) {
			fail();
		}
		
		//tear-down: NONE in this test method
	}

	@Test
	/**
	 * Above Upper Bound for value of a cell for calculateRowTotal
	 */
	public void calculateRowTotal_ValueAUB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(50));
				one(nomValues).getColumnCount();
				will(returnValue(50));
				for(int i = 0; i < 50; i++) {
					one(nomValues).getValue(25,i);
					will(returnValue(Double.MAX_VALUE+1));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateRowTotal(nomValues,25);
		//verify
		assertEquals(result, (Double.MAX_VALUE+1)*50, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Upper Bound for value of a cell for calculateRowTotal
	 */
	public void calculateRowTotal_ValueUB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(50));
				one(nomValues).getColumnCount();
				will(returnValue(50));
				for(int i = 0; i < 50; i++) {
					one(nomValues).getValue(25,i);
					will(returnValue(Double.MAX_VALUE));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateRowTotal(nomValues,25);
		//verify
		assertEquals(result, (Double.MAX_VALUE)*50, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Below Upper Bound for value of a cell for calculateRowTotal
	 */
	public void calculateRowTotal_ValueBUB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(50));
				one(nomValues).getColumnCount();
				will(returnValue(50));
				for(int i = 0; i < 50; i++) {
					one(nomValues).getValue(25,i);
					will(returnValue(Double.MAX_VALUE/50));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateRowTotal(nomValues,25);
		//verify
		assertEquals(result, (Double.MAX_VALUE), .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Above Lower Bound for value of a cell for calculateRowTotal
	 */
	public void calculateRowTotal_ValueALB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(50));
				one(nomValues).getColumnCount();
				will(returnValue(50));
				for(int i = 0; i < 50; i++) {
					one(nomValues).getValue(25,i);
					will(returnValue(0.00025));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateRowTotal(nomValues,25);
		//verify
		assertEquals(result, (0.00025*50), .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Lower Bound for value of a cell for calculateRowTotal
	 */
	public void calculateRowTotal_ValueLB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(50));
				one(nomValues).getColumnCount();
				will(returnValue(50));
				for(int i = 0; i < 50; i++) {
					one(nomValues).getValue(25,i);
					will(returnValue(Double.MIN_VALUE));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateRowTotal(nomValues,25);
		//verify
		assertEquals(result, (Double.MIN_VALUE*50), .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Below Lower Bound for value of a cell for calculateRowTotal
	 */
	public void calculateRowTotal_ValueBLB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(50));
				one(nomValues).getColumnCount();
				will(returnValue(50));
				for(int i = 0; i < 50; i++) {
					one(nomValues).getValue(25,i);
					will(returnValue(Double.MIN_VALUE/50));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateRowTotal(nomValues,25);
		//verify
		assertEquals(result, (Double.MIN_VALUE), .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	//=============================================================================
		//CalculateColumnTotal Test
	//=============================================================================
		// The test strategy used for CalculateColumnTotal was Weak Robust Testing methods
		// The three main variables that were being tested were the selected Column(Column),
		// the size of the Values2D array(Array), and the size of the value stored
		// in each cell(Value)
		// The Modifier After the variables states how that variable was tested, AUB(Above Upper
		// Bound), UB(Upper Bound), BUB(Below Upper Bound), NOM(Nominal), ALB(Above Upper Bound),
		// LB(Lower Bound), and BLB(Below Lower Bound)
		// The Upper and Lower Bounds are specified in the document
	//=============================================================================
	
	@Test
	/**
	 * Nominal Test for calculateColumnTotal
	 */
	public void calculateColumnTotal_NOM(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(50));
				one(nomValues).getColumnCount();
				will(returnValue(50));
				for(int i = 0; i < 50; i++) {
					one(nomValues).getValue(i,25);
					will(returnValue(1000));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateColumnTotal(nomValues,25);
		//verify
		assertEquals(result, 1000*50, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Above Upper Bound for Column Selected for calculateColumnTotal
	 */
	public void calculateColumnTotal_ColumnAUB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(50));
				one(nomValues).getColumnCount();
				will(returnValue(50));
				for(int i = 0; i < 50; i++) {
					one(nomValues).getValue(i,60);
					will(returnValue(1000));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateColumnTotal(nomValues,60);
		//verify
		assertEquals(result, 0, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Upper Bound for Column Selected for calculateColumnTotal
	 */
	public void calculateColumnTotal_ColumnUB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(50));
				one(nomValues).getColumnCount();
				will(returnValue(50));
				for(int i = 0; i < 50; i++) {
					one(nomValues).getValue(i,49);
					will(returnValue(1000));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateColumnTotal(nomValues,49);
		//verify
		assertEquals(result, 1000*50, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Below Upper Bound for Column Selected for calculateColumnTotal
	 */
	public void calculateColumnTotal_ColumnBUB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(50));
				one(nomValues).getColumnCount();
				will(returnValue(50));
				for(int i = 0; i < 50; i++) {
					one(nomValues).getValue(i,45);
					will(returnValue(1000));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateColumnTotal(nomValues,45);
		//verify
		assertEquals(result, 1000*50, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Above Lower Bound for Column Selected for calculateColumnTotal
	 */
	public void calculateColumnTotal_ColumnALB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(50));
				one(nomValues).getColumnCount();
				will(returnValue(50));
				for(int i = 0; i < 50; i++) {
					one(nomValues).getValue(i,5);
					will(returnValue(1000));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateColumnTotal(nomValues,5);
		//verify
		assertEquals(result, 1000*50, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Lower Bound for Column Selected for calculateColumnTotal
	 */
	public void calculateColumnTotal_ColumnLB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(50));
				one(nomValues).getColumnCount();
				will(returnValue(50));
				for(int i = 0; i < 50; i++) {
					one(nomValues).getValue(i,0);
					will(returnValue(1000));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateColumnTotal(nomValues,0);
		//verify
		assertEquals(result, 1000*50, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Below Lower Bound for Column Selected for calculateColumnTotal
	 */
	public void calculateColumnTotal_ColumnBLB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(50));
				one(nomValues).getColumnCount();
				will(returnValue(50));
				for(int i = 0; i < 50; i++) {
					one(nomValues).getValue(i,-1);
					will(returnValue(1000));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateColumnTotal(nomValues,-1);
		//verify
		assertEquals(result, 0, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Above Upper Bound for Array Size for calculateColumnTotal
	 */
	public void calculateColumnTotal_ArrayAUB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(200));
				one(nomValues).getColumnCount();
				will(returnValue(200));
				for(int i = 0; i < 200; i++) {
					one(nomValues).getValue(i,100);
					will(returnValue(1000));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateColumnTotal(nomValues,100);
		//verify
		assertEquals(result, 1000*200, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Upper Bound for Array Size for calculateColumnTotal
	 */
	public void calculateColumnTotal_ArrayUB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(100));
				one(nomValues).getColumnCount();
				will(returnValue(100));
				for(int i = 0; i < 100; i++) {
					one(nomValues).getValue(i,50);
					will(returnValue(1000));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateColumnTotal(nomValues,50);
		//verify
		assertEquals(result, 1000*100, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	
	@Test
	/**
	 * Below Upper Bound for Array Size for calculateColumnTotal
	 */
	public void calculateColumnTotal_ArrayBUB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(90));
				one(nomValues).getColumnCount();
				will(returnValue(95));
				for(int i = 0; i < 90; i++) {
					one(nomValues).getValue(i,45);
					will(returnValue(1000));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateColumnTotal(nomValues,45);
		//verify
		assertEquals(result, 1000*90, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Above Lower Bound for Array Size for calculateColumnTotal
	 */
	public void calculateColumnTotal_ArrayALB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(5));
				one(nomValues).getColumnCount();
				will(returnValue(3));
				for(int i = 0; i < 5; i++) {
					one(nomValues).getValue(i,2);
					will(returnValue(1000));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateColumnTotal(nomValues,2);
		//verify
		assertEquals(result, 1000*5, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Lower Bound for Array Size for calculateColumnTotal
	 */
	public void calculateColumnTotal_ArrayLB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(0));
				one(nomValues).getColumnCount();
				will(returnValue(0));
				for(int i = 0; i < 0; i++) {
					one(nomValues).getValue(i,0);
					will(returnValue(1000));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateColumnTotal(nomValues,0);
		//verify
		assertEquals(result, 1000*0, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Below Lower Bound for Array Size for calculateColumnTotal
	 */
	public void calculateColumnTotal_ArrayBLB(){
		//setup
		try {
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(-1));
				one(nomValues).getColumnCount();
				will(returnValue(-1));
				for(int i = -1; i < 1; i++) {
					one(nomValues).getValue(i,-1);
					will(returnValue(1000));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateColumnTotal(null,-1);
		//verify
		assertEquals(result, 0, .000000001d);
		}catch(InvalidParameterException e) {
			assertEquals(1,1);
		}catch(Exception e) {
			fail();
		}
		
		//tear-down: NONE in this test method
	}

	@Test
	/**
	 * Above Upper Bound for value of a cell for calculateColumnTotal
	 */
	public void calculateColumnTotal_ValueAUB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(50));
				one(nomValues).getColumnCount();
				will(returnValue(50));
				for(int i = 0; i < 50; i++) {
					one(nomValues).getValue(i,25);
					will(returnValue(Double.MAX_VALUE+1));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateColumnTotal(nomValues,25);
		//verify
		assertEquals(result, (Double.MAX_VALUE+1)*50, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Upper Bound for value of a cell for calculateColumnTotal
	 */
	public void calculateColumnTotal_ValueUB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(50));
				one(nomValues).getColumnCount();
				will(returnValue(50));
				for(int i = 0; i < 50; i++) {
					one(nomValues).getValue(i,25);
					will(returnValue(Double.MAX_VALUE));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateColumnTotal(nomValues,25);
		//verify
		assertEquals(result, (Double.MAX_VALUE)*50, .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Below Upper Bound for value of a cell for calculateColumnTotal
	 */
	public void calculateColumnTotal_ValueBUB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(50));
				one(nomValues).getColumnCount();
				will(returnValue(50));
				for(int i = 0; i < 50; i++) {
					one(nomValues).getValue(i,25);
					will(returnValue(Double.MAX_VALUE/50));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateColumnTotal(nomValues,25);
		//verify
		assertEquals(result, (Double.MAX_VALUE), .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Above Lower Bound for value of a cell for calculateColumnTotal
	 */
	public void calculateColumnTotal_ValueALB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(50));
				one(nomValues).getColumnCount();
				will(returnValue(50));
				for(int i = 0; i < 50; i++) {
					one(nomValues).getValue(i,25);
					will(returnValue(0.00025));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateColumnTotal(nomValues,25);
		//verify
		assertEquals(result, (0.00025*50), .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Lower Bound for value of a cell for calculateColumnTotal
	 */
	public void calculateColumnTotal_ValueLB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(50));
				one(nomValues).getColumnCount();
				will(returnValue(50));
				for(int i = 0; i < 50; i++) {
					one(nomValues).getValue(i,25);
					will(returnValue(Double.MIN_VALUE));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateColumnTotal(nomValues,25);
		//verify
		assertEquals(result, (Double.MIN_VALUE*50), .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Below Lower Bound for value of a cell for calculateColumnTotal
	 */
	public void calculateColumnTotal_ValueBLB(){
		//setup
		Mockery mockingContext = new Mockery();
		Values2D nomValues = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(nomValues).getRowCount();
				will(returnValue(50));
				one(nomValues).getColumnCount();
				will(returnValue(50));
				for(int i = 0; i < 50; i++) {
					one(nomValues).getValue(i,25);
					will(returnValue(Double.MIN_VALUE/50));
				}
			}
		}); 
		
		//exercise
		double result = DataUtilities.calculateColumnTotal(nomValues,25);
		//verify
		assertEquals(result, (Double.MIN_VALUE), .000000001d);
		
		//tear-down: NONE in this test method
	}
	
	//=============================================================================
		//getCumulativePercentages Test
	//=============================================================================
		// The test strategy used for getCumulativePercentages was Weak Robust Testing methods
		// The two main variables that were the number of values within the KeyedValues
		// parameter(Array), and the size of the value stored in each value(Value)
		// The Modifier After the variables states how that variable was tested, AUB(Above Upper
		// Bound), UB(Upper Bound), BUB(Below Upper Bound), NOM(Nominal), ALB(Above Upper Bound),
		// LB(Lower Bound), and BLB(Below Lower Bound)
		// The Upper and Lower Bounds are specified in the document
	//=============================================================================
	
	@Test
	/**
	 * Nominal value test for getCumulativePercentages
	 */
	public void getCumulativePercentages_NOM(){
		//setup
		Mockery mockingContext = new Mockery();
		KeyedValues keyedValues = mockingContext.mock(KeyedValues.class);
		mockingContext.checking(new Expectations() {
			{
				allowing(keyedValues).getItemCount();
				will(returnValue(3));
				allowing(keyedValues).getValue(0);
				will(returnValue(10));
				allowing(keyedValues).getKey(0);
				will(returnValue(1));
				allowing(keyedValues).getValue(1);
				will(returnValue(20));
				allowing(keyedValues).getKey(1);
				will(returnValue(2));
				allowing(keyedValues).getValue(2);
				will(returnValue(30));
				allowing(keyedValues).getKey(2);
				will(returnValue(3));
			}
		}); 
		
		//exercise
		KeyedValues result = DataUtilities.getCumulativePercentages(keyedValues);
		
		//verify
		assertEquals(result.getValue(0).doubleValue(), (10/60) , .000000001d);
		assertEquals(result.getValue(0).doubleValue(), (30/60) , .000000001d);
		assertEquals(result.getValue(0).doubleValue(), (60/60) , .000000001d);
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Above Upper Bound test for number of Values for getCumulativePercentages
	 */
	public void getCumulativePercentages_ArrayAUB(){
		//setup
		Mockery mockingContext = new Mockery();
		KeyedValues keyedValues = mockingContext.mock(KeyedValues.class);
		mockingContext.checking(new Expectations() {
			{
				allowing(keyedValues).getItemCount();
				will(returnValue(5));
				allowing(keyedValues).getValue(0);
				will(returnValue(10));
				allowing(keyedValues).getKey(0);
				will(returnValue(1));
				allowing(keyedValues).getValue(1);
				will(returnValue(10));
				allowing(keyedValues).getKey(1);
				will(returnValue(2));
				allowing(keyedValues).getValue(2);
				will(returnValue(10));
				allowing(keyedValues).getKey(2);
				will(returnValue(3));
				allowing(keyedValues).getValue(3);
				will(returnValue(10));
				allowing(keyedValues).getKey(3);
				will(returnValue(4));
				allowing(keyedValues).getValue(4);
				will(returnValue(10));
				allowing(keyedValues).getKey(4);
				will(returnValue(5));
				allowing(keyedValues).getValue(5);
				will(returnValue(10));
				allowing(keyedValues).getKey(5);
				will(returnValue(6));
			}
		}); 
		
		//exercise
		KeyedValues result = DataUtilities.getCumulativePercentages(keyedValues);
		
		//verify
		assertEquals(result.getValue(0).doubleValue(), (10/50) , .000000001d);
		assertEquals(result.getValue(0).doubleValue(), (20/50) , .000000001d);
		assertEquals(result.getValue(0).doubleValue(), (30/50) , .000000001d);
		assertEquals(result.getValue(0).doubleValue(), (40/50) , .000000001d);
		assertEquals(result.getValue(0).doubleValue(), (50/50) , .000000001d);
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Upper Bound test for number of Values for getCumulativePercentages
	 */
	public void getCumulativePercentages_ArrayUB(){
		//setup
		Mockery mockingContext = new Mockery();
		KeyedValues keyedValues = mockingContext.mock(KeyedValues.class);
		mockingContext.checking(new Expectations() {
			{
				allowing(keyedValues).getItemCount();
				will(returnValue(5));
				allowing(keyedValues).getValue(0);
				will(returnValue(10));
				allowing(keyedValues).getKey(0);
				will(returnValue(1));
				allowing(keyedValues).getValue(1);
				will(returnValue(10));
				allowing(keyedValues).getKey(1);
				will(returnValue(2));
				allowing(keyedValues).getValue(2);
				will(returnValue(10));
				allowing(keyedValues).getKey(2);
				will(returnValue(3));
				allowing(keyedValues).getValue(3);
				will(returnValue(10));
				allowing(keyedValues).getKey(3);
				will(returnValue(4));
				allowing(keyedValues).getValue(4);
				will(returnValue(20));
				allowing(keyedValues).getKey(4);
				will(returnValue(5));
			}
		}); 
		
		//exercise
		KeyedValues result = DataUtilities.getCumulativePercentages(keyedValues);
		
		//verify
		assertEquals(result.getValue(0).doubleValue(), (10/60) , .000000001d);
		assertEquals(result.getValue(0).doubleValue(), (20/60) , .000000001d);
		assertEquals(result.getValue(0).doubleValue(), (30/60) , .000000001d);
		assertEquals(result.getValue(0).doubleValue(), (40/60) , .000000001d);
		assertEquals(result.getValue(0).doubleValue(), (60/60) , .000000001d);
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Below Upper Bound test for number of Values for getCumulativePercentages
	 */
	public void getCumulativePercentages_ArrayBUB(){
		//setup
		Mockery mockingContext = new Mockery();
		KeyedValues keyedValues = mockingContext.mock(KeyedValues.class);
		mockingContext.checking(new Expectations() {
			{
				allowing(keyedValues).getItemCount();
				will(returnValue(4));
				allowing(keyedValues).getValue(0);
				will(returnValue(10));
				allowing(keyedValues).getKey(0);
				will(returnValue(1));
				allowing(keyedValues).getValue(1);
				will(returnValue(10));
				allowing(keyedValues).getKey(1);
				will(returnValue(2));
				allowing(keyedValues).getValue(2);
				will(returnValue(10));
				allowing(keyedValues).getKey(2);
				will(returnValue(3));
				allowing(keyedValues).getValue(3);
				will(returnValue(10));
				allowing(keyedValues).getKey(3);
				will(returnValue(4));
			}
		}); 
		
		//exercise
		KeyedValues result = DataUtilities.getCumulativePercentages(keyedValues);
		
		//verify
		assertEquals(result.getValue(0).doubleValue(), (10/40) , .000000001d);
		assertEquals(result.getValue(0).doubleValue(), (20/40) , .000000001d);
		assertEquals(result.getValue(0).doubleValue(), (30/40) , .000000001d);
		assertEquals(result.getValue(0).doubleValue(), (40/40) , .000000001d);
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Above Lower Bound test for number of Values for getCumulativePercentages
	 */
	public void getCumulativePercentages_ArrayALB(){
		//setup
		Mockery mockingContext = new Mockery();
		KeyedValues keyedValues = mockingContext.mock(KeyedValues.class);
		mockingContext.checking(new Expectations() {
			{
				allowing(keyedValues).getItemCount();
				will(returnValue(1));
				allowing(keyedValues).getValue(0);
				will(returnValue(20));
				allowing(keyedValues).getKey(0);
				will(returnValue(1));
			}
		}); 
		
		//exercise
		KeyedValues result = DataUtilities.getCumulativePercentages(keyedValues);
		
		//verify
		assertEquals(result.getValue(0).doubleValue(), (20/20) , .000000001d);
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Lower Bound test for number of Values for getCumulativePercentages
	 */
	public void getCumulativePercentages_ArrayLB(){
		//setup
		try {
			Mockery mockingContext = new Mockery();
			KeyedValues keyedValues = mockingContext.mock(KeyedValues.class);
			mockingContext.checking(new Expectations() {
				{
					allowing(keyedValues).getItemCount();
					will(returnValue(0));
				}
			}); 
			
			//exercise
			KeyedValues result = DataUtilities.getCumulativePercentages(keyedValues);
			
			//verify
			assertEquals(result.getValue(0).doubleValue(), 0 , .000000001d);
			//tear-down: NONE in this test method
		}catch(InvalidParameterException e) {
			assertEquals(1,1);
		}catch(Exception e) {
			fail();
		}
	}
	
	@Test
	/**
	 * Below Lower Bound test for number of Values for getCumulativePercentages
	 */
	public void getCumulativePercentages_ArrayBLB(){
		//setup
		try {
			//exercise
			KeyedValues result = DataUtilities.getCumulativePercentages(null);
			
			//verify
			assertEquals(result.getValue(0).doubleValue(), 1 , .000000001d);
			//tear-down: NONE in this test method
		}catch(InvalidParameterException e) {
			assertEquals(1,1);
		}catch(Exception e) {
			fail();
		}
	}
	
	@Test
	/**
	 * Above Lower Bound test for number of Values for getCumulativePercentages
	 */
	public void getCumulativePercentages_ValueAUB(){
		//setup
		Mockery mockingContext = new Mockery();
		KeyedValues keyedValues = mockingContext.mock(KeyedValues.class);
		mockingContext.checking(new Expectations() {
			{
				allowing(keyedValues).getItemCount();
				will(returnValue(3));
				allowing(keyedValues).getValue(0);
				will(returnValue(Double.MAX_VALUE+10));
				allowing(keyedValues).getKey(0);
				will(returnValue(1));
				allowing(keyedValues).getValue(1);
				will(returnValue(20));
				allowing(keyedValues).getKey(1);
				will(returnValue(2));
				allowing(keyedValues).getValue(2);
				will(returnValue(20));
				allowing(keyedValues).getKey(2);
				will(returnValue(3));
			}
		}); 
		
		//exercise
		KeyedValues result = DataUtilities.getCumulativePercentages(keyedValues);
		
		//verify
		assertEquals(result.getValue(0).doubleValue(), ((Double.MAX_VALUE)/(Double.MAX_VALUE+40)) , .000000001d);
		assertEquals(result.getValue(1).doubleValue(), ((Double.MAX_VALUE+20)/(Double.MAX_VALUE+40)) , .000000001d);
		assertEquals(result.getValue(2).doubleValue(), (1) , .000000001d);
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Above Lower Bound test for number of Values for getCumulativePercentages
	 */
	public void getCumulativePercentages_ValueUB(){
		//setup
		Mockery mockingContext = new Mockery();
		KeyedValues keyedValues = mockingContext.mock(KeyedValues.class);
		mockingContext.checking(new Expectations() {
			{
				allowing(keyedValues).getItemCount();
				will(returnValue(3));
				allowing(keyedValues).getValue(0);
				will(returnValue(20));
				allowing(keyedValues).getKey(0);
				will(returnValue(1));
				allowing(keyedValues).getValue(1);
				will(returnValue(Double.MAX_VALUE));
				allowing(keyedValues).getKey(1);
				will(returnValue(2));
				allowing(keyedValues).getValue(2);
				will(returnValue(20));
				allowing(keyedValues).getKey(2);
				will(returnValue(3));
			}
		}); 
		
		//exercise
		KeyedValues result = DataUtilities.getCumulativePercentages(keyedValues);
		
		//verify
		assertEquals(result.getValue(0).doubleValue(), ((20)/(Double.MAX_VALUE+40)) , .000000001d);
		assertEquals(result.getValue(1).doubleValue(), ((20)/(Double.MAX_VALUE+40)) , .000000001d);
		assertEquals(result.getValue(2).doubleValue(), (1) , .000000001d);
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Below Lower Bound test for number of Values for getCumulativePercentages
	 */
	public void getCumulativePercentages_ValueBUB(){
		//setup
		Mockery mockingContext = new Mockery();
		KeyedValues keyedValues = mockingContext.mock(KeyedValues.class);
		mockingContext.checking(new Expectations() {
			{
				allowing(keyedValues).getItemCount();
				will(returnValue(3));
				allowing(keyedValues).getValue(0);
				will(returnValue(20));
				allowing(keyedValues).getKey(0);
				will(returnValue(1));
				allowing(keyedValues).getValue(1);
				will(returnValue(Double.MAX_VALUE-40));
				allowing(keyedValues).getKey(1);
				will(returnValue(2));
				allowing(keyedValues).getValue(2);
				will(returnValue(20));
				allowing(keyedValues).getKey(2);
				will(returnValue(3));
			}
		}); 
		
		//exercise
		KeyedValues result = DataUtilities.getCumulativePercentages(keyedValues);
		
		//verify
		assertEquals(result.getValue(0).doubleValue(), ((20)/(Double.MAX_VALUE)) , .000000001d);
		assertEquals(result.getValue(1).doubleValue(), ((20)/(Double.MAX_VALUE)) , .000000001d);
		assertEquals(result.getValue(2).doubleValue(), (1) , .000000001d);
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Above Lower Bound test for number of Values for getCumulativePercentages
	 */
	public void getCumulativePercentages_ValueALB(){
		//setup
		Mockery mockingContext = new Mockery();
		KeyedValues keyedValues = mockingContext.mock(KeyedValues.class);
		mockingContext.checking(new Expectations() {
			{
				allowing(keyedValues).getItemCount();
				will(returnValue(3));
				allowing(keyedValues).getValue(0);
				will(returnValue(0.00001));
				allowing(keyedValues).getKey(0);
				will(returnValue(1));
				allowing(keyedValues).getValue(1);
				will(returnValue(0.00002));
				allowing(keyedValues).getKey(1);
				will(returnValue(2));
				allowing(keyedValues).getValue(2);
				will(returnValue(0.00001));
				allowing(keyedValues).getKey(2);
				will(returnValue(3));
			}
		}); 
		
		//exercise
		KeyedValues result = DataUtilities.getCumulativePercentages(keyedValues);
		
		//verify
		assertEquals(result.getValue(0).doubleValue(), (0.00001/0.00004) , .000000001d);
		assertEquals(result.getValue(1).doubleValue(), (0.00003/0.00004) , .000000001d);
		assertEquals(result.getValue(2).doubleValue(), (1) , .000000001d);
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Lower Bound test for number of Values for getCumulativePercentages
	 */
	public void getCumulativePercentages_ValueLB(){
		//setup
		Mockery mockingContext = new Mockery();
		KeyedValues keyedValues = mockingContext.mock(KeyedValues.class);
		mockingContext.checking(new Expectations() {
			{
				allowing(keyedValues).getItemCount();
				will(returnValue(3));
				allowing(keyedValues).getValue(0);
				will(returnValue(0.00001));
				allowing(keyedValues).getKey(0);
				will(returnValue(1));
				allowing(keyedValues).getValue(1);
				will(returnValue(Double.MIN_VALUE));
				allowing(keyedValues).getKey(1);
				will(returnValue(2));
				allowing(keyedValues).getValue(2);
				will(returnValue(0.00001));
				allowing(keyedValues).getKey(2);
				will(returnValue(3));
			}
		}); 
		
		//exercise
		KeyedValues result = DataUtilities.getCumulativePercentages(keyedValues);
		
		//verify
		assertEquals(result.getValue(0).doubleValue(), (0.00001/(0.00002 + Double.MIN_VALUE)) , .000000001d);
		assertEquals(result.getValue(1).doubleValue(), ((0.00001 + Double.MIN_VALUE) /(Double.MIN_VALUE + 0.00002)) , .000000001d);
		assertEquals(result.getValue(2).doubleValue(), (1) , .000000001d);
		//tear-down: NONE in this test method
	}
	
	@Test
	/**
	 * Below Lower Bound test for number of Values for getCumulativePercentages
	 */
	public void getCumulativePercentages_ValueBLB(){
		//setup
		Mockery mockingContext = new Mockery();
		KeyedValues keyedValues = mockingContext.mock(KeyedValues.class);
		mockingContext.checking(new Expectations() {
			{
				allowing(keyedValues).getItemCount();
				will(returnValue(3));
				allowing(keyedValues).getValue(0);
				will(returnValue(0.00001));
				allowing(keyedValues).getKey(0);
				will(returnValue(1));
				allowing(keyedValues).getValue(1);
				will(returnValue(Double.MIN_VALUE/2));
				allowing(keyedValues).getKey(1);
				will(returnValue(2));
				allowing(keyedValues).getValue(2);
				will(returnValue(0.00001));
				allowing(keyedValues).getKey(2);
				will(returnValue(3));
			}
		}); 
		
		//exercise
		KeyedValues result = DataUtilities.getCumulativePercentages(keyedValues);
		
		//verify
		assertEquals(result.getValue(0).doubleValue(), (0.00001/(0.00002 + (Double.MIN_VALUE/2))) , .000000001d);
		assertEquals(result.getValue(1).doubleValue(), ((0.00001 + (Double.MIN_VALUE/2) /((Double.MIN_VALUE/2) + 0.00002))) , .000000001d);
		assertEquals(result.getValue(2).doubleValue(), (1) , .000000001d);
		//tear-down: NONE in this test method
	}
	
	//@After
    public void tearDown() throws Exception{
    }
	
	//@AfterClass
    public static void tearDownAfterClass() throws Exception{

    }

}